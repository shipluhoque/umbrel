var dojoLocalPort = "$DOJO_LOCAL_PORT";
var dojoHiddenService = "$DOJO_HIDDEN_SERVICE";
var whirlpoolHiddenService = "$WHIRLPOOL_HIDDEN_SERVICE";
var bitcoinNetwork = "$COMMON_BTC_NETWORK";
var dojoAdminKey = "$NODE_ADMIN_KEY";
var whirlpoolApiKey = "$WHIRLPOOL_API_KEY";
var dojoSupportPrefix = "$NODE_PREFIX_SUPPORT";
